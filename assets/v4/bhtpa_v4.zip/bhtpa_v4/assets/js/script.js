
$(document).ready(function() {
    $(window).scroll(function() {
      if ($(document).scrollTop() > 50) {
        $("header").addClass("fixed-header");
      } else {
        $("header").removeClass("fixed-header");
      
     
      }
    });
  });
  
  //Floating menu
  $(".floating-corner .icon i").on('click', function(){
    $(".floating-corner .content").toggleClass("content-disable");
  });
  
  //Hamburger menu search icon
  $("header #modalPoll-1 .form-inline .fa-search").on('click', function(){
      $("header #modalPoll-1 .form-inline").toggleClass("search-active");
  });
  
  $('.digitalbd #slides').slideshow({
    randomize: true,      // Randomize the play order of the slides.
      slideDuration: 3000,  // Duration of each induvidual slide.
      fadeDuration: 2000,    // Duration of the fading transition. Should be shorter than slideDuration.
      animate: true,        // Turn css animations on or off.
      pauseOnTabBlur: true, // Pause the slideshow when the tab is out of focus. This prevents glitches with setTimeout().
      enableLog: false      // Enable log messages to the console. Useful for debugging.
  });

  /*========map==========*/
  
  var mymap = L.map('mapid2').setView([23.75, 90.39], 8);
 
  L.tileLayer.grayscale('https://api.mapbox.com/styles/v1/mapbox/light-v10.html?title=true&access_token=pk.eyJ1IjoicmFzZWxhaHNhbiIsImEiOiJja2hvZ29lNTcwM2J5MnptczhrMHh2c2kzIn0.5qU5TXDRThLniUDYRy8sxg', {
    maxZoom: 18,
 
    id: 'mapbox/light-v10',
    tileSize: 512,
    zoomOffset: -1
  }).addTo(mymap);
  
  
  var jsr = L.marker([23.15, 89.22]).addTo(mymap);
  var bongobondhu = L.marker([24.06, 90.22]).addTo(mymap);
  var rajshahi = L.marker([24.37, 88.55]).addTo(mymap);
  var sylhet = L.marker([25.05, 91.79]).addTo(mymap);
  var janatatower = L.marker([23.75, 90.39]).addTo(mymap);
  
  jsr.bindPopup("<img class='img-fluid rounded' src='/assets/img/shsp.jpg'><h6>Sekh Hasina Software Technology Park!</h6><a href='#'>visit here</a>").openPopup();
  rajshahi.bindPopup("<img class='img-fluid rounded' src='/assets/img/rhtp.jpg'><h6>Bangabandhu Sheikh Mujib Hi-Tech Park, Rajshahi</h6><a href='#'>visit here</a>").openPopup();
  sylhet.bindPopup("<img class='img-fluid rounded' src='/assets/img/sylhet-park.jpg'><h6>Bangabandhu Sheikh Mujib Hi-Tech Park, Sylhet</h6><a href='#'>visit here</a>").openPopup();
  janatatower.bindPopup("<img class='img-fluid rounded' src='/assets/img/janata-tower.jpg'><h6 class=''>Janata Tower Hi-Tech Park, Dhaka</h6><a href='#'>visit here</a>").openPopup();
  bongobondhu.bindPopup("<img class='img-fluid rounded' src='/assets/img/kaliakair-park.jpg'><h6>Kaliakair Hi-Tech Park, Gazipur</h6><a href='#'>visit here</a>").openPopup();
  